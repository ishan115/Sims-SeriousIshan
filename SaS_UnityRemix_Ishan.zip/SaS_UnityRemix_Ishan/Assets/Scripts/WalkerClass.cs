﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class WalkerClass : MonoBehaviour
{

    public float x;
    public float y;

    [SerializeField] public Camera cam;

    GameObject walkerGO;

    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 1;

        walkerGO = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Destroy(walkerGO.GetComponent<SphereCollider>());

        x = 0;
        y = 0;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void sphereMoving()
    {
        int choiceMouse = Random.Range(0, 2);

        if (choiceMouse == 1)
        {
            step();
        }
        else
        {
            mouseFollow();
        }
    }

    public void mouseFollow()
    {
        Vector3 pos = cam.ScreenToWorldPoint(Input.mousePosition);
        Vector3 pos1 = pos - walkerGO.transform.position;

        //Debug.Log("Position difference is " + pos);
        //Debug.Break();

        x += pos1.x;
        y += pos1.y;

        if (pos.x > x)
        {
            x++;
        }
        else if (pos.x < x)
        {
            x--;
        }
        if (pos.y > y)
        {
            y++;
        }
        else if (pos.y < y)
        {
            y--;
        }

        walkerGO.transform.position = new Vector3(x, y, 0F);
    }
    public void step()
    {
        //Each frame choose a new Random number 0,1,2,3, 
        //If the number is equal to one of those values, take a step
        int choice = Random.Range(0, 4);
        if (choice == 0)
        {
            x++;
        }
        else if (choice == 1)
        {
            x--;
        }
        else if (choice == 3)
        {
            y++;
        }
        else
        {
            y--;
            x++;
        }
        walkerGO.transform.position = new Vector3(x, y, 0F);
    }

    //Now let's draw the path of the Mover by creating spheres in its position in the most recent frame.
    public void draw()
    {
        //This creates a sphere GameObject
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Destroy(sphere.GetComponent<SphereCollider>());
        //This sets our ink "sphere game objects" at the position of the Walker GameObject (walkerGO) at the current frame
        //to draw the path

        sphere.transform.position = new Vector3((int)x, (int)y, 0F);
    }

}
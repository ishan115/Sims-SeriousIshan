﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chapter4Fig1 : MonoBehaviour
{

    public particleChapter4_1 ps;


    // Start is called before the first frame update
    void Start()
    {
        Instantiate(ps);

    }

    // Update is called once per frame
    void Update()
    {

    }


    

}
